module Carmen
  VERSION = '1.0.0.beta2'
end
